<form action="data_fc.php" method="post">
  
  <h1> Formulir </h1>
    <tr>
      <td> Jumlah Lembar Fotocopy </td>
    <td><input type="text" name="jumlah"></d>
  </tr>
  <tr>
    <input type="submit" name="hitung" value="Hitung"></td>
  </tr>
</form>