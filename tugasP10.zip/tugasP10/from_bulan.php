<form action="data_bulan.php" method="post">
  
  <h1> Formulir </h1>
    <tr>
      <td>bulan ini</td>
  </tr>
  <tr>
  <tr>
    <input type="submit" name="cek" value="cek"></td>
  </tr>
</form>