<html>
<head>
<title>Belajar PHP </title>
</head>
<body>
<h2> Hitung Nilai Mahasiswa</h2>
<style type="text/css">
#mhs{
 //margin: 10px;
 position: absolute;
 left: 60px;
}
</style>
<form action ="data_nilai.php" method="POST">
 Nama :
 <input id="mhs" type="text" name="nama"><br>
 
 <br>
 nilai:
 <input id="mhs" type="nilai" name="nilai"><br>
<br>

 <input id="mhs" type="submit" value="Hasil">

</form>
</body>
</html>